using System;
using System.Collections.Generic;

namespace pedidos_service.Domain.Events
{
    public class PedidoCreado
    {
        public string PedidoId { get; set; } = string.Empty;
        public string ClienteId { get; set; } = string.Empty;
        public List<string> Items { get; set; } = new();
        public DateTime FechaCreacion { get; set; } = DateTime.UtcNow;
    }
}