﻿namespace pedidos_service.Application.DTOs
{
    public class CambioEstadoDTO
    {
        public string NuevoEstado { get; set; }
    }
}
