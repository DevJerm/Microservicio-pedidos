using System.Threading.Tasks;

namespace pedidos_service.Application.Interfaces
{
    public interface IEventPublisher
    {
        Task PublicarAsync<T>(T evento) where T : class;
    }
}