using pedidos_service.Application.Interfaces;
using System;
using System.Text.Json;
using System.Threading.Tasks;

namespace pedidos_service.Infrastructure.Messaging
{
    public class InMemoryEventPublisher : IEventPublisher
    {
        public Task PublicarAsync<T>(T evento) where T : class
        {
            var nombreEvento = evento.GetType().Name;
            var contenido = JsonSerializer.Serialize(evento);
            Console.WriteLine($"[EVENTO PUBLICADO] {nombreEvento}: {contenido}");
            return Task.CompletedTask;
        }
    }
}